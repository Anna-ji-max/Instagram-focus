package com.dhyan.guard

import android.content.Context
import android.content.SharedPreferences

class Prefs(ctx: Context) {
    val sp: SharedPreferences =
        ctx.applicationContext.getSharedPreferences("dhyan", Context.MODE_PRIVATE)

    var enabled: Boolean
        get() = sp.getBoolean("enabled", true)
        set(v) { sp.edit().putBoolean("enabled", v).apply() }

    /** 0 = follow phone, 1 = light, 2 = dark */
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }

    var pauseAudio: Boolean
        get() = sp.getBoolean("pauseAudio", false)
        set(v) { sp.edit().putBoolean("pauseAudio", v).apply() }

    var debug: Boolean
        get() = sp.getBoolean("debug", false)
        set(v) { sp.edit().putBoolean("debug", v).apply() }
}
