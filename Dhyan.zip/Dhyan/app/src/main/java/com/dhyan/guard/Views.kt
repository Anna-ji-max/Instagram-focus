package com.dhyan.guard

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.min

private const val C_ORANGE = 0xFFFA7E1E.toInt()
private const val C_PINK = 0xFFD62976.toInt()
private const val C_PURPLE = 0xFF962FBF.toInt()
private const val C_BLUE = 0xFF4F5BD5.toInt()

/** Instagram-style "loading" skeleton that never finishes loading. Swallows every touch. */
class CoverView(ctx: Context) : View(ctx) {
    companion object { const val FEED = 0; const val GRID = 1 }

    private var dark = false
    private var style = FEED
    private var searchBar = false
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rf = RectF()
    private var phase = 0f
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1400
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { phase = it.animatedValue as Float; invalidate() }
    }

    fun setLook(dark: Boolean, style: Int, bar: Boolean) {
        if (dark != this.dark || style != this.style || bar != searchBar) {
            this.dark = dark; this.style = style; this.searchBar = bar
            invalidate()
        }
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE) { if (!anim.isStarted) anim.start() } else anim.cancel()
    }

    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onTouchEvent(event: MotionEvent): Boolean = true

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawColor(if (dark) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
        val base = if (dark) 0xFF262626.toInt() else 0xFFEFEFEF.toInt()
        val hi = if (dark) 0xFF3C3C3C.toInt() else 0xFFFAFAFA.toInt()
        val band = w * 0.7f
        val x = -band + (w + band * 2) * phase
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(x, 0f, x + band, 0f, intArrayOf(base, hi, base),
            floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        if (style == GRID) grid(c, w, h) else feed(c, w, h)
        p.shader = null
    }

    private fun rr(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float) {
        rf.set(l, t, r, b); c.drawRoundRect(rf, rad, rad, p)
    }

    private fun feed(c: Canvas, w: Float, h: Float) {
        var y = 52 * d
        while (y < h) {
            c.drawCircle(28 * d, y + 20 * d, 16 * d, p)
            rr(c, 54 * d, y + 10 * d, 204 * d, y + 19 * d, 4 * d)
            rr(c, 54 * d, y + 26 * d, 144 * d, y + 33 * d, 4 * d)
            val my = y + 50 * d
            c.drawRect(0f, my, w, my + w, p)
            val ay = my + w + 22 * d
            c.drawCircle(24 * d, ay, 11 * d, p)
            c.drawCircle(60 * d, ay, 11 * d, p)
            c.drawCircle(96 * d, ay, 11 * d, p)
            rr(c, 16 * d, ay + 26 * d, 16 * d + w * 0.6f, ay + 34 * d, 4 * d)
            y = ay + 70 * d
        }
        spinner(c, w)
    }

    private fun grid(c: Canvas, w: Float, h: Float) {
        var y = 8 * d
        if (searchBar) { rr(c, 14 * d, y, w - 14 * d, y + 38 * d, 12 * d); y += 50 * d }
        val g = 1.5f * d
        val cell = (w - 2 * g) / 3f
        while (y < h) {
            for (i in 0..2) { val x = i * (cell + g); c.drawRect(x, y, x + cell, y + cell, p) }
            y += cell + g
        }
    }

    private fun spinner(c: Canvas, w: Float) {
        val cx = w / 2f; val cy = 24 * d; val r = 9 * d
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.6f * d
        p.strokeCap = Paint.Cap.ROUND
        p.shader = SweepGradient(cx, cy, intArrayOf(C_ORANGE, C_PINK, C_PURPLE, C_BLUE, C_ORANGE), null)
        c.save()
        c.rotate(phase * 360f, cx, cy)
        rf.set(cx - r, cy - r, cx + r, cy + r)
        c.drawArc(rf, 0f, 280f, false, p)
        c.restore()
        p.shader = null
        p.style = Paint.Style.FILL
    }
}

/** Covers the Reels tab button with a gradient ∆ (drawn as a path, so no font needed). */
class BtnView(ctx: Context) : View(ctx) {
    private var dark = false
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    fun setDark(v: Boolean) { if (v != dark) { dark = v; invalidate() } }

    override fun onTouchEvent(event: MotionEvent): Boolean = true

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawColor(if (dark) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
        val s = min(w, h) * 0.34f
        val cx = w / 2f; val cy = h / 2f
        path.reset()
        path.moveTo(cx, cy - s * 0.85f)
        path.lineTo(cx + s, cy + s * 0.75f)
        path.lineTo(cx - s, cy + s * 0.75f)
        path.close()
        p.style = Paint.Style.STROKE
        p.strokeWidth = s * 0.28f
        p.strokeJoin = Paint.Join.ROUND
        p.shader = LinearGradient(cx - s, cy - s, cx + s, cy + s,
            intArrayOf(C_ORANGE, C_PINK, C_BLUE), null, Shader.TileMode.CLAMP)
        c.drawPath(path, p)
        p.shader = null
    }
}

/**
 * Transparent window over a reel/post opened from chat.
 * Taps and horizontal swipes are re-sent to Instagram; vertical swipes are swallowed,
 * so you cannot move to the next reel/post.
 */
class GateView(
    ctx: Context,
    private val onTap: (Float, Float, Long) -> Unit,
    private val onSwipe: (Float, Float, Float, Float, Long) -> Unit
) : View(ctx) {
    private var x0 = 0f; private var y0 = 0f; private var t0 = 0L
    private val slop = 14 * resources.displayMetrics.density

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> { x0 = e.rawX; y0 = e.rawY; t0 = e.eventTime }
            MotionEvent.ACTION_UP -> {
                val dx = e.rawX - x0; val dy = e.rawY - y0
                val dur = e.eventTime - t0
                if (abs(dx) < slop && abs(dy) < slop) onTap(e.rawX, e.rawY, dur)
                else if (abs(dx) > abs(dy) * 1.5f) onSwipe(x0, y0, e.rawX, e.rawY, dur)
                // vertical movement: swallowed on purpose
            }
        }
        return true
    }
}
