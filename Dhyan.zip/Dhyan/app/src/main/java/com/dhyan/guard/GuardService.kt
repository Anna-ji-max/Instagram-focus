package com.dhyan.guard

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Rect
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.TextView
import kotlin.math.max

/**
 * Dhyan guard. Strategy:
 *  - The moment Instagram appears we show a full "loading" cover (default-deny).
 *  - Then we look at which screen is showing and only uncover what is allowed.
 *  - Covers are SMALL windows that sit exactly over the part to hide, so the story tray,
 *    chats, camera, your profile header etc. receive touches directly (no lag, stories open).
 *  - All windows are created once and only moved / shown / hidden afterwards.
 */
class GuardService : AccessibilityService(), SharedPreferences.OnSharedPreferenceChangeListener {

    companion object {
        const val IG = "com.instagram.android"
        const val IGID = "com.instagram.android:id/"
        const val K_HOME = 0; const val K_SEARCH = 1; const val K_CLIPS = 2
        const val K_PROFILE = 3; const val K_DM = 4; const val K_OTHER = 5
        val TRAY_IDS = listOf("reels_tray_container", "reels_tray", "stories_tray", "reel_tray", "reels_tray_recycler_view")
    }

    private class Tab(val kind: Int, val rect: Rect, val selected: Boolean)
    private class Snap { val ids = HashSet<String>(); val texts = ArrayList<String>() }
    private class Plan(
        val cover: Rect?, val style: Int = CoverView.FEED, val bar: Boolean = false,
        val btn: Rect? = null, val gate: Rect? = null, val label: String,
        val tabsTop: Int = 0, val silence: Boolean = false
    )

    private val h = Handler(Looper.getMainLooper())
    private lateinit var prefs: Prefs
    private lateinit var wm: WindowManager
    private lateinit var body: CoverView
    private lateinit var btn: BtnView
    private lateinit var gate: GateView
    private lateinit var bodyLp: WindowManager.LayoutParams
    private lateinit var btnLp: WindowManager.LayoutParams
    private lateinit var gateLp: WindowManager.LayoutParams
    private var debugView: TextView? = null
    private var debugLp: WindowManager.LayoutParams? = null

    private var sw = 0; private var sh = 0; private var density = 1f
    private var statusH = 0; private var navH = 0

    private var igActive = false
    private var activeSince = 0L
    private var lastRun = 0L
    private var pending = false
    private var lastTabsTop = 0
    private var lastBtn: Rect? = null
    private var trayEverSeen = false
    private var lastSnap = 0L
    private var lastDump = ""
    private var focusReq: AudioFocusRequest? = null
    private var holdingFocus = false
    private var gateBusy = false

    private val runEval = Runnable { pending = false; lastRun = SystemClock.uptimeMillis(); evaluate() }

    // ---------------------------------------------------------------- lifecycle

    override fun onServiceConnected() {
        super.onServiceConnected()
        prefs = Prefs(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        measure()
        body = CoverView(this).also { it.visibility = View.GONE }
        btn = BtnView(this).also { it.visibility = View.GONE }
        gate = GateView(this, { x, y, dur -> forwardTap(x, y, dur) },
            { a, b, c, d, dur -> forwardSwipe(a, b, c, d, dur) }).also { it.visibility = View.GONE }
        bodyLp = newLp(); btnLp = newLp(); gateLp = newLp()
        safeAdd(body, bodyLp); safeAdd(gate, gateLp); safeAdd(btn, btnLp)
        prefs.sp.registerOnSharedPreferenceChangeListener(this)
        updateDebug()
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        try { if (::prefs.isInitialized) prefs.sp.unregisterOnSharedPreferenceChangeListener(this) } catch (_: Throwable) {}
        if (::wm.isInitialized && ::body.isInitialized) {
            for (v in listOfNotNull(body, btn, gate, debugView)) try { wm.removeView(v) } catch (_: Throwable) {}
            holdAudio(false)
        }
        super.onDestroy()
    }

    override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) {
        h.post {
            updateDebug()
            if (!prefs.enabled) { igActive = false; render(null) } else if (igActive) schedule()
        }
    }

    // ---------------------------------------------------------------- events

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (!prefs.enabled) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName) return

        if (pkg == IG) {
            if (!igActive) {
                igActive = true
                activeSince = SystemClock.uptimeMillis()
                trayEverSeen = false
                measure()
                render(fullPlan("cold-open"))          // cover first, think later
            }
            if (e.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
                val id = e.source?.viewIdResourceName?.substringAfter('/')
                if (id == "clips_tab" || id == "search_tab") render(fullPlan("fast:$id"))
            }
            schedule()
            return
        }

        // another package: ignore keyboard / system UI / system dialogs, otherwise Instagram left the screen
        if (pkg.startsWith("com.android.systemui") || pkg == "android" ||
            pkg.contains("inputmethod") || pkg.contains("keyboard") ||
            pkg.contains("honeyboard") || pkg.contains("swiftkey")) return
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && igActive) {
            igActive = false
            render(null)
        }
    }

    private fun schedule() {
        if (pending) return
        pending = true
        val wait = max(0L, lastRun + 25 - SystemClock.uptimeMillis())
        if (wait == 0L) h.postAtFrontOfQueue(runEval) else h.postDelayed(runEval, wait)
    }

    private fun evaluate() {
        if (!igActive || !prefs.enabled) return
        measure()
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != IG) return
        val plan = try { classify(root) } catch (t: Throwable) { fullPlan("error:" + t.javaClass.simpleName) }
        render(plan)
    }

    // ---------------------------------------------------------------- classification

    private fun fullPlan(label: String): Plan {
        val top = if (lastTabsTop > 0) lastTabsTop else sh - navH - dp(56)
        return Plan(Rect(0, statusH, sw, top), CoverView.FEED, false, lastBtn, null, label, 0, true)
    }

    private fun classify(root: AccessibilityNodeInfo): Plan {
        val bottomSafe = sh - navH
        val tabs = findTabs(root)

        if (tabs.size >= 2) {
            val tabsTop = tabs.minOf { it.rect.top }.coerceIn(sh / 2, sh)
            var reel: Rect? = tabs.firstOrNull { it.kind == K_CLIPS }?.rect
            if (reel == null) {
                val sorted = tabs.sortedBy { it.rect.left }
                val hi = sorted.indexOfFirst { it.kind == K_HOME }
                if (hi >= 0 && hi + 1 < sorted.size && sorted[hi + 1].kind == K_OTHER) reel = sorted[hi + 1].rect
            }
            lastBtn = reel?.let { Rect(it) }
            var sel = tabs.firstOrNull { it.selected }?.kind ?: -1
            if (sel == -1) {
                sel = if (findTray(root) != null) K_HOME else {
                    val s = snap(root)
                    if (s.ids.any { it.startsWith("direct_") || it.contains("inbox") }) K_DM else -1
                }
            }
            lastDump = "tabs=" + tabs.joinToString { "${it.kind}${if (it.selected) "*" else ""}" } + " sel=$sel"
            if (sel != K_HOME) trayEverSeen = false

            return when (sel) {
                K_HOME -> homePlan(root, tabsTop)
                K_SEARCH -> Plan(Rect(0, statusH, sw, tabsTop), CoverView.GRID, true, lastBtn, null, "search tab", tabsTop, true)
                K_CLIPS -> Plan(Rect(0, statusH, sw, tabsTop), CoverView.FEED, false, lastBtn, null, "reels tab", tabsTop, true)
                K_PROFILE -> Plan(Rect(0, profileCoverTop(root), sw, tabsTop), CoverView.GRID, false, lastBtn, null, "own profile", tabsTop)
                K_DM, K_OTHER -> Plan(null, btn = lastBtn, label = "chat/other tab", tabsTop = tabsTop)
                else -> Plan(Rect(0, statusH, sw, tabsTop), CoverView.FEED, false, lastBtn, null, "unknown tab", tabsTop, true)
            }
        }

        // ---- no bottom tab bar: full-screen pages
        lastBtn = null
        trayEverSeen = false
        val s = snap(root)
        lastDump = s.ids.sorted().joinToString("\n") + "\n--\n" + s.texts.joinToString(" | ")
        val ids = s.ids
        val sheet = ids.any { it.contains("bottom_sheet") || it.contains("comment_composer") || it.contains("layout_comment") }

        return when {
            ids.any { it.startsWith("profile_header") || it.startsWith("profile_tab_layout") || it.startsWith("profile_viewpager") } ->
                Plan(Rect(0, profileCoverTop(root), sw, sh - navH), CoverView.GRID, false, null, null, "other profile")
            ids.any { it.startsWith("clips_viewer") || it.startsWith("clips_video") || it.startsWith("clips_swipe") || it.startsWith("clips_ufi") || it.startsWith("clips_author") } ->
                Plan(null, gate = if (sheet) null else Rect(0, statusH + dp(56), sw, sh - navH - dp(140)), label = "reel from chat (locked)")
            ids.any { it.contains("row_feed") } ->
                Plan(null, gate = if (sheet) null else Rect(0, statusH + dp(56), sw, sh - navH), label = "post from chat (locked)")
            ids.any { it.startsWith("reel_viewer") } -> Plan(null, label = "story")
            ids.size < 5 && SystemClock.uptimeMillis() - activeSince < 4000 -> fullPlan("loading")
            else -> Plan(null, label = "allowed page")
        }
    }

    private fun homePlan(root: AccessibilityNodeInfo, tabsTop: Int): Plan {
        val tray = findTray(root)
        val r = Rect()
        var coverTop = statusH + dp(52)
        var snapNeeded = false
        if (tray != null) {
            tray.getBoundsInScreen(r)
            if (r.height() > 0) {
                trayEverSeen = true
                coverTop = max(coverTop, r.bottom)
                if (r.top < statusH + dp(40)) snapNeeded = true
            }
        } else if (trayEverSeen) snapNeeded = true
        if (snapNeeded) snapTop(root, tray)
        return Plan(Rect(0, coverTop, sw, tabsTop), CoverView.FEED, false, lastBtn, null, "home (feed hidden)", tabsTop, true)
    }

    private fun snapTop(root: AccessibilityNodeInfo, from: AccessibilityNodeInfo?) {
        val now = SystemClock.uptimeMillis()
        if (now - lastSnap < 150) return
        lastSnap = now
        var n = from?.parent
        var guard = 0
        while (n != null && guard++ < 8) {
            if (n.isScrollable) { n.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD); return }
            n = n.parent
        }
        findScrollable(root, 0)?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }

    private fun findScrollable(n: AccessibilityNodeInfo?, depth: Int): AccessibilityNodeInfo? {
        if (n == null || depth > 12) return null
        if (n.isScrollable) {
            val r = Rect(); n.getBoundsInScreen(r)
            if (r.height() > sh / 3) return n
        }
        for (i in 0 until n.childCount) findScrollable(n.getChild(i), depth + 1)?.let { return it }
        return null
    }

    private fun findTray(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        for (id in TRAY_IDS) {
            val n = root.findAccessibilityNodeInfosByViewId(IGID + id).firstOrNull()
            if (n != null) return n
        }
        return null
    }

    private fun findTabs(root: AccessibilityNodeInfo): List<Tab> {
        val out = ArrayList<Tab>()
        val map = listOf("feed_tab" to K_HOME, "search_tab" to K_SEARCH, "clips_tab" to K_CLIPS,
            "profile_tab" to K_PROFILE, "direct_tab" to K_DM, "creation_tab" to K_OTHER)
        for ((id, kind) in map) {
            val n = root.findAccessibilityNodeInfosByViewId(IGID + id).firstOrNull() ?: continue
            val r = Rect(); n.getBoundsInScreen(r)
            if (r.height() > 0) out.add(Tab(kind, r, n.isSelected || n.parent?.isSelected == true))
        }
        if (out.size >= 2) return out
        out.clear()
        val byText = listOf("Home" to K_HOME, "Search and explore" to K_SEARCH, "Reels" to K_CLIPS,
            "Profile" to K_PROFILE, "Messages" to K_DM)
        for ((t, kind) in byText) {
            for (n in root.findAccessibilityNodeInfosByText(t)) {
                val r = Rect(); n.getBoundsInScreen(r)
                if (r.top > sh * 0.85f && r.height() > 0 && out.none { it.kind == kind }) {
                    out.add(Tab(kind, r, n.isSelected || n.parent?.isSelected == true)); break
                }
            }
        }
        return out
    }

    private fun profileCoverTop(root: AccessibilityNodeInfo): Int {
        var best = -1
        for (t in listOf("Edit profile", "Share profile", "Message", "Following", "Follow", "Requested", "Subscribe")) {
            for (n in root.findAccessibilityNodeInfosByText(t)) {
                val r = Rect(); n.getBoundsInScreen(r)
                val cls = n.className?.toString() ?: ""
                if (r.width() > 0 && r.top > statusH && r.bottom < sh * 0.75f && (n.isClickable || cls.contains("Button")))
                    best = max(best, r.bottom)
            }
        }
        return if (best > 0) best + dp(10) else statusH + (sh * 0.36f).toInt()
    }

    private fun snap(root: AccessibilityNodeInfo): Snap {
        val s = Snap()
        var count = 0
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            if (n == null || count > 600 || depth > 40) return
            count++
            n.viewIdResourceName?.let { s.ids.add(it.substringAfter('/')) }
            if (s.texts.size < 60) {
                n.text?.let { if (it.isNotEmpty()) s.texts.add(it.toString().take(30)) }
                n.contentDescription?.let { if (it.isNotEmpty()) s.texts.add(it.toString().take(30)) }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        return s
    }

    // ---------------------------------------------------------------- windows

    private fun render(plan: Plan?) {
        if (plan == null) {
            setWin(body, bodyLp, null); setWin(btn, btnLp, null); setWin(gate, gateLp, null)
            holdAudio(false); debugText("idle"); return
        }
        val dark = isDark()
        if (plan.cover != null) body.setLook(dark, plan.style, plan.bar)
        btn.setDark(dark)
        setWin(body, bodyLp, plan.cover)
        setWin(btn, btnLp, plan.btn)
        setWin(gate, gateLp, plan.gate, !gateBusy)
        if (plan.tabsTop > 0) lastTabsTop = plan.tabsTop
        holdAudio(plan.silence && plan.cover != null)
        debugText(plan.label)
    }

    private fun setWin(v: View, lp: WindowManager.LayoutParams, r: Rect?, touchable: Boolean = true) {
        if (r == null || r.width() <= 0 || r.height() <= 0) {
            if (v.visibility != View.GONE) {
                v.visibility = View.GONE
                lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                safeUpdate(v, lp)
            }
            return
        }
        val nf = if (touchable) lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                 else lp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        if (lp.x != r.left || lp.y != r.top || lp.width != r.width() || lp.height != r.height() || lp.flags != nf) {
            lp.x = r.left; lp.y = r.top; lp.width = r.width(); lp.height = r.height(); lp.flags = nf
            safeUpdate(v, lp)
        }
        if (v.visibility != View.VISIBLE) v.visibility = View.VISIBLE
    }

    private fun newLp(): WindowManager.LayoutParams {
        val lp = WindowManager.LayoutParams(
            1, 1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode =
            WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        return lp
    }

    private fun safeAdd(v: View, lp: WindowManager.LayoutParams) { try { wm.addView(v, lp) } catch (_: Throwable) {} }
    private fun safeUpdate(v: View, lp: WindowManager.LayoutParams) { try { wm.updateViewLayout(v, lp) } catch (_: Throwable) {} }

    @Suppress("DEPRECATION")
    private fun measure() {
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        sw = dm.widthPixels; sh = dm.heightPixels; density = dm.density
        statusH = dimen("status_bar_height"); navH = dimen("navigation_bar_height")
    }

    private fun dimen(name: String): Int {
        val id = resources.getIdentifier(name, "dimen", "android")
        return if (id > 0) resources.getDimensionPixelSize(id) else 0
    }

    private fun dp(v: Int) = (v * density).toInt()

    private fun isDark(): Boolean = when (prefs.theme) {
        1 -> false
        2 -> true
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    // ---------------------------------------------------------------- gate: forward taps / horizontal swipes

    private fun forwardTap(x: Float, y: Float, dur: Long) {
        val p = Path().apply { moveTo(x, y) }
        inject(p, if (dur > 350) dur else 40)
    }

    private fun forwardSwipe(x0: Float, y0: Float, x1: Float, y1: Float, dur: Long) {
        val p = Path().apply { moveTo(x0, y0); lineTo(x1, y1) }
        inject(p, dur.coerceIn(60L, 600L))
    }

    private fun inject(path: Path, dur: Long) {
        gateBusy = true
        gateLp.flags = gateLp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        safeUpdate(gate, gateLp)
        h.postDelayed({
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, dur)).build()
            val ok = dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(gd: GestureDescription?) { restoreGate() }
                override fun onCancelled(gd: GestureDescription?) { restoreGate() }
            }, h)
            if (!ok) restoreGate()
        }, 40)
    }

    private fun restoreGate() {
        gateBusy = false
        if (gate.visibility == View.VISIBLE) {
            gateLp.flags = gateLp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            safeUpdate(gate, gateLp)
        }
    }

    // ---------------------------------------------------------------- optional audio pause

    private fun holdAudio(on: Boolean) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (on && prefs.pauseAudio && !holdingFocus) {
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE).build())
                .setOnAudioFocusChangeListener { }.build()
            focusReq = req
            holdingFocus = am.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        } else if ((!on || !prefs.pauseAudio) && holdingFocus) {
            focusReq?.let { am.abandonAudioFocusRequest(it) }
            holdingFocus = false
        }
    }

    // ---------------------------------------------------------------- debug bubble (tap = copy screen IDs)

    private fun updateDebug() {
        if (prefs.debug && debugView == null) {
            val tv = TextView(this).apply {
                setTextColor(Color.WHITE); textSize = 11f
                setBackgroundColor(0xCC962FBF.toInt())
                setPadding(dp(8), dp(4), dp(8), dp(4))
                text = "∆ debug"
                setOnClickListener {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("dhyan", lastDump))
                    text = "∆ copied"
                }
            }
            val lp = newLp()
            lp.width = WindowManager.LayoutParams.WRAP_CONTENT
            lp.height = WindowManager.LayoutParams.WRAP_CONTENT
            lp.gravity = Gravity.TOP or Gravity.END
            lp.y = statusH + dp(6)
            lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            safeAdd(tv, lp)
            debugView = tv; debugLp = lp
        } else if (!prefs.debug && debugView != null) {
            try { wm.removeView(debugView) } catch (_: Throwable) {}
            debugView = null; debugLp = null
        }
    }

    private fun debugText(label: String) { debugView?.text = "∆ $label" }
}
