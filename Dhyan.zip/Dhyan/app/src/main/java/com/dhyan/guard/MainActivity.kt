package com.dhyan.guard

import android.app.Activity
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var prefs: Prefs
    private lateinit var root: LinearLayout
    private lateinit var scroll: ScrollView
    private var night = false
    private val grad = intArrayOf(0xFFFA7E1E.toInt(), 0xFFD62976.toInt(), 0xFF962FBF.toInt(), 0xFF4F5BD5.toInt())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        scroll = ScrollView(this)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(36), dp(20), dp(28)) }
        scroll.addView(root)
        setContentView(scroll)
    }

    override fun onResume() { super.onResume(); build() }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun fg() = if (night) Color.WHITE else 0xFF111111.toInt()
    private fun dim() = if (night) 0xFFA8A8A8.toInt() else 0xFF737373.toInt()

    private fun serviceOn(): Boolean {
        val en = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        return en.contains("$packageName/")
    }

    private fun text(s: String, size: Float, bold: Boolean = false, color: Int = fg()) =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color)
            if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

    private fun gradBg(r: Int) = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, grad).apply { cornerRadius = dp(r).toFloat() }

    private fun gButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; setTextColor(Color.WHITE); textSize = 15f
        background = gradBg(14)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(10) }
    }

    private fun toggle(label: String, on: Boolean, change: (Boolean) -> Unit) = Switch(this).apply {
        text = label; isChecked = on; setTextColor(fg()); textSize = 15f
        setPadding(0, dp(10), 0, dp(10))
        setOnCheckedChangeListener { _, v -> change(v) }
    }

    private fun build() {
        night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        scroll.setBackgroundColor(if (night) Color.BLACK else Color.WHITE)
        root.removeAllViews()

        val title = text("∆ Dhyan", 34f, true).apply {
            post { paint.shader = LinearGradient(0f, 0f, width.toFloat().coerceAtLeast(1f), 0f, grad, null, Shader.TileMode.CLAMP); invalidate() }
        }
        root.addView(title)
        root.addView(text("Instagram for people, not for scrolling.", 14f, false, dim()))

        val on = serviceOn()
        root.addView(text(if (on) "● Guard service is ON" else "● Guard service is OFF", 15f, true,
            if (on) 0xFF2E9E57.toInt() else 0xFFE03131.toInt()).apply { setPadding(0, dp(18), 0, dp(4)) })

        root.addView(text("Setup", 18f, true).apply { setPadding(0, dp(16), 0, 0) })
        root.addView(text("1. Android 13+: open App info → ⋮ menu → \"Allow restricted settings\".", 13f, false, dim()))
        root.addView(gButton("Open App info") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        root.addView(text("2. Accessibility → Installed apps → Dhyan → switch on. No \"display over other apps\" permission needed.", 13f, false, dim()).apply { setPadding(0, dp(12), 0, 0) })
        root.addView(gButton("Open Accessibility settings") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        root.addView(gButton("Open Instagram") {
            val i = packageManager.getLaunchIntentForPackage("com.instagram.android")
            if (i != null) startActivity(i) else Toast.makeText(this, "Instagram not installed", Toast.LENGTH_SHORT).show()
        })

        root.addView(text("Controls", 18f, true).apply { setPadding(0, dp(22), 0, dp(4)) })
        root.addView(toggle("Guard active", prefs.enabled) { prefs.enabled = it })

        root.addView(text("Cover colour", 14f, false, dim()).apply { setPadding(0, dp(8), 0, dp(6)) })
        val seg = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Phone", "Light", "Dark").forEachIndexed { idx, label ->
            val sel = prefs.theme == idx
            seg.addView(TextView(this).apply {
                text = label; gravity = Gravity.CENTER; textSize = 14f
                setTextColor(if (sel) Color.WHITE else fg())
                background = if (sel) gradBg(12) else GradientDrawable().apply {
                    cornerRadius = dp(12).toFloat(); setColor(if (night) 0xFF262626.toInt() else 0xFFEFEFEF.toInt())
                }
                layoutParams = LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(8) }
                setOnClickListener { prefs.theme = idx; build() }
            })
        }
        root.addView(seg)

        root.addView(toggle("Pause hidden-feed audio (best effort)", prefs.pauseAudio) { prefs.pauseAudio = it })
        root.addView(text("Uses audio focus, so it may also pause your music while a hidden page is covered. Off by default; your volume panel is never touched.", 12f, false, dim()))
        root.addView(toggle("Debug label (tap it to copy screen IDs)", prefs.debug) { prefs.debug = it })
        root.addView(text("Instagram updates change internal names. If a screen is covered/uncovered wrongly, turn this on, open that screen, tap the purple label and paste the copied text to Claude.", 12f, false, dim()))
        root.addView(text("No internet permission. Nothing is stored or sent. The guard only runs while Instagram is on screen.", 12f, false, dim()).apply { setPadding(0, dp(18), 0, 0) })
    }
}
