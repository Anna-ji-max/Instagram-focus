# Dhyan  ∆  (v2)

Instagram without the endless scroll. Android only. Needs: Accessibility permission (no overlay permission).

## Build on your phone (GitHub mobile website)
1. github.com -> New repository (private is fine) -> create it.
2. Add file -> Create new file -> name it `.github/workflows/build.yml` -> paste the contents of `build.yml` -> Commit.
   (Do this FIRST. The folder name starts with a dot, so it cannot be uploaded from the phone; it has to be typed.)
3. Add file -> Upload files -> pick `Dhyan.zip` (leave it zipped) -> Commit.
4. Actions tab -> "Build Dhyan APK" runs by itself (~4 min). When green, open Releases -> build-N -> tap `Dhyan.apk`.
5. Install it (allow "install unknown apps" for your browser), open Dhyan, follow the 2 setup buttons.

## What it does
| Place in Instagram | Result |
|---|---|
| Cold open | Loading cover appears the moment Instagram starts, uncovered only after the screen is recognised |
| Home | Header + story tray stay live (tap / swipe natively). Feed under the tray is covered; feed can't be scrolled away |
| Search tab | Fully covered |
| Reels tab | Fully covered; tab button replaced by gradient ∆ |
| Messages tab, DMs, camera, stories | Untouched |
| Reel / post received in chat | Playable; vertical swipe to next is swallowed; taps + horizontal swipes still work |
| Own profile | Top (photo, stats, bio, buttons, menu) visible; highlights/grid covered |
| Other profile | Same as own profile |
| Followers / following lists | Visible |

## If a screen is wrong after an Instagram update
Dhyan -> turn on "Debug label". Open the wrong screen, tap the purple label (copies screen IDs), paste them to Claude.
The IDs live in `GuardService.kt` -> `classify()` / `findTabs()` / `TRAY_IDS`.
